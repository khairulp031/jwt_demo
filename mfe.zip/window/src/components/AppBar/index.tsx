import React, { ReactElement } from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import DragIndicatorIcon from "@mui/icons-material/DragIndicator";
import AccountCircle from "@mui/icons-material/AccountCircle";
import CloseIcon from "@mui/icons-material/Close";
import MinimizeIcon from "@mui/icons-material/Minimize";
import Switch from "@mui/material/Switch";
import OpenInFullIcon from "@mui/icons-material/OpenInFull";
import CloseFullscreenIcon from "@mui/icons-material/CloseFullscreen";
import useController from "./common/useController";
import Root, { classes, PREFIX } from "./common/style";

const Fallback: React.FC = (props): ReactElement => {
  const {
    store,
    toggleColorMode,
    handleCloseWindow,
    handleMinimizeWindow,
    maxOrRestore,
    handleAccount,
    winSize,
  } = useController();
  return (
    <Root className={classes.root} data-testid={`${PREFIX}`}>
      <AppBar position="static">
        <Toolbar className={classes.toolbar}>
          <IconButton
            size="small"
            color="inherit"
            aria-label="Draggable"
            className={`title-bar-draggable ${classes.noPadding}`}
          >
            <DragIndicatorIcon />
          </IconButton>
          <Typography
            variant="h6"
            component="div"
            sx={{ flexGrow: 1 }}
            className={`title-bar-draggable ${classes.title} ${classes.noPadding}`}
          >
            My openfin with single spa app
          </Typography>
          <div>
            <Switch
              data-testid="Home__switch-id"
              checked={store.theme === "light"}
              onChange={toggleColorMode}
              color="default"
              size="small"
            />
            <IconButton
              size="small"
              aria-label="Profile"
              onClick={handleAccount}
              color="inherit"
              className={classes.noPadding}
            >
              <AccountCircle />
            </IconButton>
            <IconButton
              size="small"
              aria-label="Minimize"
              onClick={handleMinimizeWindow}
              color="inherit"
              className={classes.noPadding}
            >
              <MinimizeIcon />
            </IconButton>
            <IconButton
              size="small"
              aria-label={winSize === "normal" ? "Mazimize" : "Restore"}
              onClick={maxOrRestore}
              color="inherit"
              className={classes.noPadding}
            >
              {winSize === "normal" ? (
                <OpenInFullIcon />
              ) : (
                <CloseFullscreenIcon />
              )}
            </IconButton>
            <IconButton
              size="small"
              aria-label="Close"
              onClick={handleCloseWindow}
              color="inherit"
              className={classes.noPadding}
            >
              <CloseIcon />
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
    </Root>
  );
};

export default Fallback;
