import { render, screen, act } from "@testing-library/react";
import React from "react";
import Parent from "./";
import { PREFIX } from "./common/style";
const Comp = () => {
  throw new Error();
};

describe("AppBar component", () => {
  it("should be in the document", async () => {
    await act(async () => {
      render(
        <Parent>
          <Comp />
        </Parent>
      );
    });
    const id = screen.getByTestId(PREFIX);
    expect(id).toBeInTheDocument;
  });
});
