import React from "react";
import { useContext } from "../../../hooks/provider";
import { ActionType } from "../../../hooks/reducer/util/ActionType";
import { fin } from "@openfin/core";

const useController = () => {
  const [store, dispacth] = useContext();
  const [winSize, setWinSize] = React.useState<"normal" | "max">("normal");

  const toggleColorMode = () => {
    const mode = store.theme === "light" ? "dark" : "light";
    dispacth({ type: ActionType.SET_THEME, data: { theme: mode } });
  };

  const handleCloseWindow = () => {
    fin.Window.getCurrentSync().close().catch(console.error);
  };
  const handleMinimizeWindow = () => {
    fin.Window.getCurrentSync().minimize().catch(console.error);
  };
  const maxOrRestore = async () => {
    if ((await fin.Window.getCurrentSync().getState()) === "normal") {
      setWinSize("max");
      return await fin.Window.getCurrentSync().maximize().catch(console.error);
    }
    setWinSize("normal");
    return fin.Window.getCurrentSync().restore().catch(console.error);
  };
  const handleAccount = () => {};
  const setTheme = async (t: "light" | "dark") => {
    let theme = "light-theme";
    if (t === "dark") {
      theme = "dark";
    }
    const root = document.documentElement;
    if (theme === "light-theme") {
      root.classList.add("light-theme");
    } else {
      root.classList.remove("light-theme");
    }

    if (store.theme !== t) {
      fin.Platform.getCurrentSync().setWindowContext({ theme });
    }
  };

  React.useEffect(() => {
    setTheme(store.theme as "light" | "dark");
    window.localStorage.setItem("theme", `${store.theme}`);
  }, [store.theme]);

  return {
    store,
    toggleColorMode,
    handleCloseWindow,
    handleMinimizeWindow,
    maxOrRestore,
    handleAccount,
    winSize,
  };
};

export default useController;
