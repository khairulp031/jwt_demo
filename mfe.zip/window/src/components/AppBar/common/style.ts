import { styled } from "@mui/material/styles";

export const PREFIX = `${process.env.MFE_APP_PREFIX_STYLE}_appBar`;
export const classes = {
  root: `${PREFIX}-root`,
  toolbar: `${PREFIX}-toolbar`,
  title: `${PREFIX}-title`,
  noPadding: `${PREFIX}-noPadding`,
};

const Root = styled("section")(({ theme }) => ({
  [`&.${classes.root}`]: {
    width: "100%",
    minWidth: "640px",
    userSelect: "none",
    padding: theme.spacing(0),
    margin: theme.spacing(0),
    color: "#fff",
    "& .MuiButtonBase-root, .MuiSwitch-thumb": {
      color: "#fff",
    },
    "& *": {
      userSelect: "none",
    },
  },
  [`& .${classes.toolbar}`]: {
    minHeight: "auto !important",
    paddingLeft: "0.5rem",
    paddingRight: "0.5rem",
  },
  [`& .${classes.title}`]: {
    color: "#fff",
    fontSize: "14px",
  },
  [`& .${classes.noPadding}`]: {
    paddingTop: "2px",
    paddingBottom: "2px",
  },
}));

export default Root;
