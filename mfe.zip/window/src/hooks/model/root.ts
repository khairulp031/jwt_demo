export interface ComponentPropsDefault {
  children: React.ReactNode;
}
export interface ErrorState {
  hasError: boolean;
  error?: Error | undefined;
}
export interface User {
  id: string;
  name: string;
}
export interface RootModel {
  user?: User | undefined;
  token?: string | undefined;
  errorMsg?: string | undefined;
  isLoading?: boolean;
  theme?: string;
  isOpenFin?: boolean;
}

export const initialData: RootModel = {
  user: undefined,
  token: undefined,
  errorMsg: undefined,
  isLoading: false,
  theme: window.localStorage.getItem("theme") || "dark",
  isOpenFin: false,
};
