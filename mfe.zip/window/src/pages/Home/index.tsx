import React, { ReactElement } from "react";
import useController, { CONTAINER_ID } from "./common/useController";
import Root, { classes } from "./common/style";
import AppBar from "../../components/AppBar";

const Home: React.FC = (props): ReactElement => {
  useController(props);
  return (
    <Root className={classes.root}>
      <AppBar />
      <section id={CONTAINER_ID}></section>
    </Root>
  );
};

export default Home;
