import { styled } from "@mui/material/styles";
import { CONTAINER_ID } from "./useController";

const PREFIX = `${process.env.MFE_APP_PREFIX_STYLE}_home`;
export const classes = {
  root: `${PREFIX}-root`,
};

const Root = styled("section")(({ theme }) => ({
  [`&.${classes.root}`]: {
    width: "100%",
    padding: theme.spacing(0),
    margin: theme.spacing(0),
    [`& #${CONTAINER_ID}`]: {
      padding: 0,
      margin: 0,
      border: 0,
      width: "100% !important",
    },
    "& .lm_root": {
      height: "calc(100vh - 30px) !important", //67px is the height of the appBar
      width: "100%",
    },
  },
}));

export default Root;
