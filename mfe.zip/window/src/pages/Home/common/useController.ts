import React from "react";
import { fin } from "@openfin/core";
import { useContext } from "../../../hooks/provider";
import { ActionType } from "../../../hooks/reducer/util/ActionType";
export const CONTAINER_ID = "layout-container";
const useController = (props: any) => {
  const [store, dispacth] = useContext();
  const storageHandler = function (r) {
    console.info("storage", r);
    if (r.key === "theme" && r.newValue !== store.theme) {
      dispacth({ type: ActionType.SET_THEME, data: { theme: r.newValue } });
    }
  };
  window.addEventListener("storage", storageHandler, false);
  const init = async () => {
    await fin.Platform.Layout.init({ containerId: CONTAINER_ID });
  };
  React.useEffect(() => {
    if (window.fin) {
      init();
    }
    return () => {
      window.removeEventListener("storage", storageHandler, false);
    };
  }, []);

  return {};
};

export default useController;
