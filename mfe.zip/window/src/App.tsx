import React, { ReactElement } from "react";
import Provider from "./hooks/provider";
import ThemeProvider from "./theme";
import Home from "./pages/Home";

const App: React.FC = (): ReactElement => {
  return (
    <Provider>
      <ThemeProvider>
        <Home />
      </ThemeProvider>
    </Provider>
  );
};

export default App;
