import { createTheme, responsiveFontSizes } from "@mui/material/styles";

const Config = (mode: "light" | "dark") => {
  let config;
  if (mode === "light") {
    config = createTheme({
      palette: {
        mode: "light",
        background: {
          paper: "var(--frame-background-color)",
        },
      },
    });
  } else {
    config = createTheme({
      palette: {
        mode: "dark",
        background: {
          paper: "var(--frame-background-color)",
        },
      },
    });
  }
  //config = responsiveFontSizes(config);
  return { config };
};

export default Config;
