import { registerApplication, start } from "single-spa";
import {
  constructApplications,
  constructRoutes,
  constructLayoutEngine,
} from "single-spa-layout";
import microfrontendLayout from "./microfrontend-layout.html";

const routes = constructRoutes(microfrontendLayout);
const applications = constructApplications({
  routes,
  loadApp({ name }) {
    return System.import(name);
  },
});
const layoutEngine = constructLayoutEngine({ routes, applications });
const getPath = (origin: string) => {
  if (origin.includes("localhost")) return "/";
  else return "/config/latest";
};
applications.forEach((mfe) => {
  mfe.customProps = {
    version: `1.0.0`,
    publicUrl: `${window.location.origin}${getPath(window.location.origin)}`,
  };
  registerApplication(mfe);
});
layoutEngine.activate();
start();
