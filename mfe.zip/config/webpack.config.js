const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-ts");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");

module.exports = (webpackConfigEnv, argv) => {
  const port = process.env.port;
  const mode = process.env.mode;
  const orgName = process.env.orgName;
  const devtool =
    process.env.devtool.toLocaleLowerCase() === "false"
      ? false
      : process.env.devtool;
  const isLocal = process.env.isLocal.toLocaleLowerCase() === "true";
  const publicUrl = process.env.publicUrl || "";
  const importmap = process.env.importmap || "";
  const defaultConfig = singleSpaDefaults({
    orgName,
    projectName: "root-config",
    webpackConfigEnv,
    argv,
    disableHtmlGeneration: true,
  });

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    mode,
    devtool,
    entry: path.resolve(__dirname, "src", "root"),
    output: {
      filename: "config.js",
    },
    plugins: [
      new HtmlWebpackPlugin({
        inject: false,
        template: "src/index.ejs",
        templateParameters: {
          isLocal,
          orgName,
          publicUrl,
          importmap,
        },
      }),
    ],
    devServer: {
      port,
      proxy: {
        "/api/*": {
          target: "http://localhost:8080",
          secure: false,
          changeOrigin: true,
        },
      },
      allowedHosts: "all",
      compress: true,
      static: {
        directory: path.join(__dirname, "dist"),
      },
    },
  });
};
