import { connect, launch } from "openfin-adapter";
import { killAllRequested } from "./util";

async function launchFromNode(manifestUrl, exitMethod) {
  try {
    console.log(`Launching manifest: ${manifestUrl}`);

    const port = await launch({ manifestUrl });

    // We will use the port to connect from Node to determine when OpenFin exists.
    const fin = await connect({
      uuid: `dev-connection-${Date.now()}`, // Supply an addressable Id for the connection
      address: `ws://127.0.0.1:${port}`, // Connect to the given port.
      nonPersistent: true, // We want OpenFin to exit as our application exists.
    });

    // Once OpenFin exits we shut down the process.
    fin.once("disconnected", exitMethod);
    return fin;
  } catch (e) {
    throw new Error(`Error: \n${e}`);
  }
}

async function run(manifestUrl) {
  try {
    const fin = await launchFromNode(manifestUrl, () => {
      console.log("Disconnected");
      console.log("Exiting");
      process.exit();
    });

    const manifest = await fin.System.fetchManifest(manifestUrl);

    let quit = async () => {
      try {
        console.log("Platform quit");
        const platform = fin.Platform.wrapSync({
          uuid: manifest.platform.uuid,
        });
        await platform.quit();
      } catch {}
    };
    console.log(`Wrapped target platform: ${manifest.platform.uuid}`);

    // do something when app is closing
    process.on("exit", async () => {
      console.log("Exit called");
      await quit();
    });

    // catches ctrl+c event
    process.on("SIGINT", async () => {
      console.log("Ctrl + C called");
      killAllRequested();
    });

    console.log(`You successfully connected to the manifest: ${manifestUrl}`);
    console.log(`Please wait while the sample loads.`);
    console.log(`Use close button to quit.`);
  } catch (e) {
    throw new Error(`Error connecting: \n${e}`);
  }
}


(async () => {
  try {
    let manifestUrl = `http://localhost:9000/manifest.fin.json`;
    console.log("Launching application from:", manifestUrl);
    await run(manifestUrl);
  } catch (err) {
    console.error("err", err);
  }
})();
