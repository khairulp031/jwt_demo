import { killAllRequested } from "./util";

killAllRequested();
