import React, { ReactElement } from "react";
import { hooks } from "..";
import { RootModel, ComponentPropsDefault, initialData } from "../model/root";
import { reducers } from "../reducer";
import { IAction } from "../reducer/util/ActionType";

export const AppContext = React.createContext<
  [RootModel, React.Dispatch<IAction>]
>([initialData, () => {}]);
export const useContext = (): [RootModel, React.Dispatch<IAction>] =>
  React.useContext(AppContext);

const Provider: React.FC<ComponentPropsDefault> = (
  props: ComponentPropsDefault
): ReactElement => {
  const [store, dispatch] = React.useReducer(reducers, initialData);
  React.useEffect(() => {
    hooks.setBaseDispatch(dispatch);
    hooks.setStore(store);
  }, []);
  return (
    <AppContext.Provider value={[store, dispatch]}>
      {props.children}
    </AppContext.Provider>
  );
};

export default Provider;
