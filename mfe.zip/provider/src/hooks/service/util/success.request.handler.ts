import { getHooks } from "../..";
import { ActionType } from "../../reducer/util/ActionType";

export const requestHandler = (request: any) => {
  const { baseDispatch } = getHooks();
  baseDispatch({ type: ActionType.SET_IS_LOADING, data: { isLoading: true } });
  return request;
};
