import { AxiosResponse } from "axios";
import { getHooks } from "../..";
import { ActionType } from "../../reducer/util/ActionType";

export const successHandler =
  (service) =>
  (response: AxiosResponse): AxiosResponse => {
    const { baseDispatch } = getHooks();
    if (response && response.headers && response.headers["Authorization"]) {
      service.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${response.headers["token"]}`;
      baseDispatch({
        type: ActionType.SET_TOKEN,
        data: { token: response.headers["token"] },
      });
    }
    baseDispatch({
      type: ActionType.SET_ERRORMSG,
      data: { errorMsg: undefined },
    });
    baseDispatch({
      type: ActionType.SET_IS_LOADING,
      data: { isLoading: false },
    });
    return response;
  };
