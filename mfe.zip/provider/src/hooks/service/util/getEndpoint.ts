export const getEndPoint = (path: string) => {
  return "/api";
};
