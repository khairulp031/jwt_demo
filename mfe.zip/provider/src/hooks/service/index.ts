import axios, { AxiosRequestConfig } from "axios";
import { getEndPoint } from "./util/getEndpoint";
import { errorHandler } from "./util/error.response.handler";
import { successHandler } from "./util/succes.response.handler";
import { requestHandler } from "./util/success.request.handler";

const config: AxiosRequestConfig = {
  headers: {
    "Content-Type": "application/json",
    "Cache-Control": "no-cache",
    Accept: "application/json, text/plain",
  },
  //withCredentials: true,
  timeout: 60000,
};
const service = axios.create(config);
service.interceptors.request.use(requestHandler);
service.interceptors.response.use(successHandler(service), errorHandler);

const putService = (path, data, signal = undefined) => {
  return service.put(getEndPoint(path), data, {
    signal,
  });
};

const postService = (path, data, signal = undefined) => {
  return service.post(getEndPoint(path), data, {
    signal,
  });
};

const getService = (path, signal = undefined) => {
  return service.get(getEndPoint(path), {
    signal,
  });
};

export { putService, postService, getService };
