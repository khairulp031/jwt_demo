import { RootModel } from "../model/root";
import { IAction } from "./util/ActionType";
import rootReducer from "./root.reducers";
import { getHooks } from "..";

export const reducers = (state: RootModel, action: IAction): RootModel => {
  Object.freeze(state);
  const hooks = getHooks();
  let store: RootModel = { ...hooks.store, ...state };
  store = rootReducer(store, action);
  hooks.setStore({ ...hooks.store, ...store });
  return store;
};
