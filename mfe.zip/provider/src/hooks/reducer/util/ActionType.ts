import { RootModel } from "../../model/root";

export interface IAction {
  type: ActionType;
  data: RootModel;
}

export enum ActionType {
  SET_TOKEN = "SET_TOKEN",
  SET_ERRORMSG = "SET_ERRORMSG",
  CLEAR = "CLEAR",
  SET_USER = "SET_USER",
  SET_IS_LOADING = "SET_IS_LOADING",
  SET_THEME = "SET_THEME",
  SET_IS_OPENFIN = "SET_IS_OPENFIN",
}
