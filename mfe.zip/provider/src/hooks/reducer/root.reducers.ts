import { RootModel, initialData } from "../model/root";
import { ActionType, IAction } from "./util/ActionType";

const reducers = (store: RootModel, action: IAction): RootModel => {
  switch (action.type) {
    case ActionType.SET_TOKEN:
      store.token = action.data.token;
      break;
    case ActionType.SET_USER:
      store.user = action.data.user;
      break;
    case ActionType.SET_ERRORMSG:
      store.errorMsg = action.data.errorMsg;
      break;
    case ActionType.SET_IS_LOADING:
      store.isLoading = action.data.isLoading;
      break;
    case ActionType.SET_THEME:
      store.theme = action.data.theme;
      break;
    case ActionType.SET_IS_OPENFIN:
      store.isOpenFin = action.data.isOpenFin;
      break;
    case ActionType.CLEAR:
    default:
      store = initialData;
      break;
  }
  return store;
};

export default reducers;
