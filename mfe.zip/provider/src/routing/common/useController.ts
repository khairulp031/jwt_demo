import React from "react";
import { useContext } from "../../hooks/provider";
import { useNavigate } from "react-router-dom";
import { ActionType } from "../../hooks/reducer/util/ActionType";

const useController = () => {
  const [store, dispacth] = useContext();
  const navigate = useNavigate();
  const storageHandler = function (r) {
    console.info("storage", r);
    if (r.key === "theme") {
      dispacth({ type: ActionType.SET_THEME, data: { theme: r.newValue } });
    }
  };
  React.useEffect(() => {
    window.addEventListener("storage", storageHandler, false);
    const queryParams = new URL(document.location.href).searchParams;
    const page = queryParams.get("page");
    if (page) {
      navigate(page);
    } else {
      navigate("/home");
    }
    window.getTokenFromProvider = () => {
      /*
       // https://developers.openfin.co/of-docs/docs/channels
       from the client App:
       async function getTokenFromProvider() {
          let win=await fin.Application.getCurrentSync().getWindow();
          let token=await win.executeJavaScript(`window.getTokenFromProvider()`);
          console.info(token);
       }
       async function getTokenFromWindow() {
          let win=await fin.View.getCurrentSync().getCurrentWindow();
          let token=await win.executeJavaScript(`window.getTokenFromProvider()`);
          console.info(token);
       }
      */
      return window.localStorage.getItem("token") || undefined;
    };
    return () => {
      window.removeEventListener("storage", storageHandler, false);
      window.getTokenFromProvider = undefined;
    };
  }, []);

  React.useEffect(() => {}, []);

  return { store };
};

export default useController;
