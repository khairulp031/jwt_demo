import React, { ReactElement, Suspense } from "react";
import { Routes, Route } from "react-router-dom";
import useController from "./common/useController";
const Home = React.lazy(() => import("../pages/Home"));
const App = React.lazy(() => import("../pages/app"));

const Routing: React.FC = (): ReactElement => {
  useController();
  return (
    <>
      <Suspense fallback="Loading">
        {/* <MemoryRouter> */}
        <Routes>
          <Route path="/" element={<></>}></Route>
          <Route path="/home" element={<Home />}></Route>
          <Route path="/app" element={<App />}></Route>
        </Routes>
        {/* </MemoryRouter> */}
      </Suspense>
    </>
  );
};

export default Routing;
