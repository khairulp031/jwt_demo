import React, { ReactElement } from "react";
import { ThemeProvider as MuiThemeProvider } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import Config from "./config";
import { useContext } from "../hooks/provider";
import { ComponentPropsDefault } from "../hooks/model/root";

const ThemeProvider: React.FC<ComponentPropsDefault> = (
  props
): ReactElement => {
  const [store] = useContext();
  const { config } = Config(store.theme as "light" | "dark");
  return (
    <MuiThemeProvider theme={config}>
      <CssBaseline />
      {props.children}
    </MuiThemeProvider>
  );
};

export default ThemeProvider;
