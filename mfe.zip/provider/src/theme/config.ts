import { createTheme, responsiveFontSizes } from "@mui/material/styles";

const Config = (mode: "light" | "dark") => {
  let config = createTheme({
    palette: {
      mode,
    },
  });
  config = responsiveFontSizes(config);
  return { config };
};

export default Config;
