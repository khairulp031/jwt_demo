import React, { ReactElement } from "react";
import Typography from "@mui/material/Typography";
import useController from "./common/useController";
import Root, { classes, PREFIX } from "./common/style";
import ErrorBoundry from "../../components/ErrorBoundry";

const LoginComplete: React.FC = (props): ReactElement => {
  useController(props);

  return (
    <ErrorBoundry>
      <Root className={classes.root} data-testid={`${PREFIX}`}>
        <Typography variant="h1" gutterBottom>
          {PREFIX}
        </Typography>
      </Root>
    </ErrorBoundry>
  );
};

export default LoginComplete;
