import React from "react";

const useController = (props: any) => {
  React.useEffect(() => {}, []);
  return {};
};

export default useController;
