import React from "react";
import { useContext } from "../../../hooks/provider";
import { ActionType } from "../../../hooks/reducer/util/ActionType";
import { init as bootstrap } from "./bootstrapper";
import { fin } from "@openfin/core";

const useController = (props: any) => {
  const [store, dispacth] = useContext();
  const closeLoading = () => {
    dispacth({
      type: ActionType.SET_IS_LOADING,
      data: { isLoading: false },
    });
  };
  const openLoading = () => {
    dispacth({
      type: ActionType.SET_IS_LOADING,
      data: { isLoading: true },
    });
  };

  const launchView = async (url: string, targetIdentity?: OpenFin.Identity) => {
    const platform = fin.Platform.getCurrentSync();

    const viewOptions = {
      url,
      printName: "App",
      target: targetIdentity as OpenFin.Identity,
    };
    await platform.createView(viewOptions, targetIdentity);
  };

  const initFin = async () => {
    if (window.fin) {
      dispacth({
        type: ActionType.SET_IS_OPENFIN,
        data: { isOpenFin: true },
      });
      await bootstrap();
      setTimeout(async () => {
        await launchView("https://www.google.com/");
        await launchView("https://www.facebook.com/");
        await launchView("http://localhost:9000/provider/?page=/app");
      }, 2000);
    }
    closeLoading();
  };

  React.useEffect(() => {
    initFin();
  }, []);

  return {
    store,
  };
};

export default useController;
