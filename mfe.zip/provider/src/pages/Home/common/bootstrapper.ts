import { fin } from "@openfin/core";

export async function init() {
  fin.Platform.init();
  const providerWindow = fin.Window.getCurrentSync();
  await providerWindow.once("close-requested", (w) => {
    console.info(w);
  });
}
