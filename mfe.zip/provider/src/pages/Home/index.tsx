import React, { ReactElement } from "react";
import FormGroup from "@mui/material/FormGroup";
import Typography from "@mui/material/Typography";
import useController from "./common/useController";
import Root, { classes, PREFIX } from "./common/style";
import ErrorBoundry from "../../components/ErrorBoundry";
import Loader from "../../components/Loader";

const Home: React.FC = (props): ReactElement => {
  const { store } = useController(props);

  return (
    <ErrorBoundry>
      <Root className={classes.root} data-testid={`${PREFIX}`}>
        <Typography variant="h1" gutterBottom>
          Provider Home
        </Typography>
        <FormGroup>
          <div>is Openfin: {store.isOpenFin ? " true" : " false"}</div>
          <div>mode: {store.theme}</div>
        </FormGroup>
        {store.isLoading && <Loader />}
      </Root>
    </ErrorBoundry>
  );
};

export default Home;
