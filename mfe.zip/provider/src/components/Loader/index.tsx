import React, { ReactElement } from "react";
import useController from "./common/useController";
import Root, { classes } from "./common/style";
import { ErrorState } from "../../hooks/model/root";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";

const Fallback: React.FC = (props): ReactElement => {
  useController();
  return (
    <Root className={classes.root} data-testid="FallbackError__page-id">
      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={true}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
    </Root>
  );
};

export default Fallback;
