import React from "react";

const useController = () => {
  React.useEffect(() => {}, []);

  return {};
};

export default useController;
