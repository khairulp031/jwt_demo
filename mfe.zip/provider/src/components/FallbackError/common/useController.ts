import React from "react";
import { ErrorState } from "../../../hooks/model/root";
import { putService } from "../../../hooks/service";

const useController = (props: ErrorState) => {
  React.useEffect(() => {
    props.error && putService("/error", { ...props.error }).catch((e) => {});
  }, [props.error]);

  return {};
};

export default useController;
