import { render, screen } from "@testing-library/react";
import React from "react";
import Root from ".";

describe("FallbackError component", () => {
  it("should be in the document", () => {
    render(
      <Root
        hasError={true}
        error={{ name: "", message: "test FallbackError", stack: "test" }}
      />
    );
    const id = screen.getByTestId("FallbackError__page-id");
    expect(id).toBeInTheDocument;
    expect(screen.getByText(/test FallbackError/i)).toBeInTheDocument();
  });
});
