import React, { ReactElement } from "react";
import useController from "./common/useController";
import Root, { classes } from "./common/style";
import { ErrorState } from "../../hooks/model/root";

const Fallback: React.FC<ErrorState> = (props: ErrorState): ReactElement => {
  useController(props);
  return (
    <Root className={classes.root} data-testid="FallbackError__page-id">
      <strong>{props.error?.name}</strong>
      <span>{props.error?.message}</span>
      <i>{props.error?.stack}</i>
    </Root>
  );
};

export default Fallback;
