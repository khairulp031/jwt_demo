import React, { ReactElement } from "react";
import Provider from "./hooks/provider";
import ThemeProvider from "./theme";
import Routing from "./routing";
import { Routes, Route, MemoryRouter } from "react-router-dom";

const App: React.FC = (): ReactElement => (
  <Provider>
    <ThemeProvider>
      <MemoryRouter>
        <Routes>
          <Route path="*" element={<Routing />}></Route>
        </Routes>
      </MemoryRouter>
    </ThemeProvider>
  </Provider>
);

export default App;
