import React from "react";
// Mock SystemJS
function mockImport(name) {
  return Promise.resolve({
    getRoot: function () {
      return <section>home</section>;
    },
  });
}
const globalAny: any = global;
globalAny.System = {
  import: jest.fn(mockImport),
};
console.error = (...args) => {};
console.log = (...args) => {};
jest.setTimeout(60000);
